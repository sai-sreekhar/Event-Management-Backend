#!/bin/bash

npm i
sls deploy
echo "Deployment Successful"